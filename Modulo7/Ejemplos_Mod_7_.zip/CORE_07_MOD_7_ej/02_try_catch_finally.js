

try {

   throw "<valor>" 
   // or throw new Error(<valor>)

} catch (exception) {

} finally {

}


